package com.mindtree.airline.model;

import java.util.List;

public class DialogflowResponse {

	private String fulfillmentText;
	
	private List<FulfillmentMessages> fulfillmentMessages;

	public String getFulfillmentText() {
		return fulfillmentText;
	}

	public void setFulfillmentText(String fulfillmentText) {
		this.fulfillmentText = fulfillmentText;
	}

	public List<FulfillmentMessages> getFulfillmentMessages() {
		return fulfillmentMessages;
	}

	public void setFulfillmentMessages(List<FulfillmentMessages> fulfillmentMessages) {
		this.fulfillmentMessages = fulfillmentMessages;
	}

	@Override
	public String toString() {
		return "DialogflowResponse [fulfillmentText=" + fulfillmentText + ", fulfillmentMessages=" + fulfillmentMessages
				+ "]";
	}
	
}
