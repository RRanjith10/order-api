package com.mindtree.airline;

import java.io.BufferedReader;
import java.io.BufferedWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import com.mindtree.airline.client.SoapClient;
import com.mindtree.airline.helper.OrderRetriveHelper;
import com.mindtree.airline.model.DialogFlowRequest;
import com.mindtree.airline.model.DialogflowResponse;
import com.ndc.orderretrieve.OrderRetrieveRQ;
import com.ndc.orderretrieve.OrderViewRS;

public class OrderApiFunction implements HttpFunction {

	private static final Logger logger = LoggerFactory.getLogger(OrderApiFunction.class);

	@Autowired
	private OrderRetriveHelper helper;

	@Autowired
	SoapClient soapClient;

	@Override
	public void service(HttpRequest request, HttpResponse response) throws Exception {

		logger.info("Started calling SoapClient");

		BufferedWriter writer = response.getWriter();
		BufferedReader reader = request.getReader();
		String httpJsonReq = reader.readLine();

		ObjectMapper mapper = new ObjectMapper();
		DialogFlowRequest dialogFlowRequest = mapper.readValue(httpJsonReq, DialogFlowRequest.class);
		
		//actual decision
		OrderRetrieveRQ req = helper.generateOrderRetReq(dialogFlowRequest);
		OrderViewRS orderViewRS = soapClient.getPnrDetails(req);
		DialogflowResponse res = helper.convertToDFResponse(orderViewRS);

		logger.info("response to DialogFlow : " + res);

		// Converting the Object to JSONString
		String jsonRes = mapper.writeValueAsString(res);
		writer.write(jsonRes);
	}

}
