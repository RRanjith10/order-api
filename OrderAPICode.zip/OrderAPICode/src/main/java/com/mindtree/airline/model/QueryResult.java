package com.mindtree.airline.model;

import java.util.Map;

public class QueryResult {

	private String queryText;
	private Map<String, String> parameters;

	public String getQueryText() {
		return queryText;
	}

	public void setQueryText(String queryText) {
		this.queryText = queryText;
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}
	
	
}
