package com.mindtree.airline.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.transport.context.TransportContext;
import org.springframework.ws.transport.context.TransportContextHolder;
import org.springframework.ws.transport.http.HttpUrlConnection;

import com.ndc.orderretrieve.OrderRetrieveRQ;
import com.ndc.orderretrieve.OrderViewRS;

@Service
public class SoapClient {

	private static final Logger logger = LoggerFactory.getLogger(SoapClient.class);
	
	@Value("${retrieveURL}")
	private String url;
	
	@Value("${retrieveClinetKeyName}")
	private String clientKeyHeader;
	
	@Value("${retrieveClinetKeyValue}")
	private String clinetKeyValue;
	
	@Value("${retrieveSoapAction}")
	private String soapAction;
	
	@Autowired
	private Jaxb2Marshaller marshaller;
	

	public OrderViewRS getPnrDetails(OrderRetrieveRQ req) {
		OrderViewRS res = new OrderViewRS();
		WebServiceTemplate template = new WebServiceTemplate(marshaller);

		try {
			res = (OrderViewRS) template.marshalSendAndReceive(url, req, getRequestCallback());
		} catch (Exception e) {
			logger.error("error during marshalSendAndReceive", e);
		}
		return res;
	}

	private WebServiceMessageCallback getRequestCallback() {
		return message -> {
			((SoapMessage) message).setSoapAction(soapAction);
			  
			TransportContext context = TransportContextHolder.getTransportContext();
			HttpUrlConnection connection = (HttpUrlConnection) context.getConnection();
			connection.addRequestHeader(clientKeyHeader, clinetKeyValue);
		};
	}


}