package com.mindtree.airline.helper;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.springframework.stereotype.Service;

import com.mindtree.airline.model.DialogFlowRequest;
import com.mindtree.airline.model.DialogflowResponse;
import com.mindtree.airline.model.FulfillmentMessages;
import com.mindtree.airline.model.Text;
import com.ndc.orderretrieve.AgencyIDType;
import com.ndc.orderretrieve.AggregatorIDType;
import com.ndc.orderretrieve.AggregatorParticipantType;
import com.ndc.orderretrieve.MsgDocumentType;
import com.ndc.orderretrieve.MsgPartiesType;
import com.ndc.orderretrieve.OrderRetrieveRQ;
import com.ndc.orderretrieve.OrderIDType;
import com.ndc.orderretrieve.OrderRetrieveRQ.Query;
import com.ndc.orderretrieve.OrderViewRS;

import com.ndc.orderretrieve.TravelAgencySenderType;

@Service
public class OrderRetriveHelper {

	public OrderRetrieveRQ generateOrderRetReq(DialogFlowRequest dialogFlowRequest) {
		
		String pnr = dialogFlowRequest.getQueryResult().getQueryText();
		OrderRetrieveRQ req = new OrderRetrieveRQ();
		MsgDocumentType doc = new MsgDocumentType();
		doc.setName("BA");
		req.setDocument(doc);
		req.setVersion("17.2");
		MsgPartiesType parties = new MsgPartiesType();
		AgencyIDType agencyId = new AgencyIDType();
		agencyId.setValue("TST100");

		MsgPartiesType.Sender sender = new MsgPartiesType.Sender();
		TravelAgencySenderType travelAgencySender = new TravelAgencySenderType();
		travelAgencySender.setName("TestAgency");
		travelAgencySender.setIATANumber("00000136");
		travelAgencySender.setAgencyID(agencyId);
		sender.setTravelAgencySender(travelAgencySender);

		parties.setSender(sender);

		QName qname = new QName("ns2:Participants");
		MsgPartiesType.Participants.Participant msgPart = new MsgPartiesType.Participants.Participant();
		AggregatorParticipantType aggregatorParticipantType = new AggregatorParticipantType();
		AggregatorIDType aggId = new AggregatorIDType();
		aggId.setValue("00073301");
		aggregatorParticipantType.setSequenceNumber(new BigInteger("123"));
		aggregatorParticipantType.setName("Mindtree");
		aggregatorParticipantType.setAggregatorID(aggId);

		msgPart.setAggregatorParticipant(aggregatorParticipantType);
		MsgPartiesType.Participants participant = new MsgPartiesType.Participants();
		JAXBElement<MsgPartiesType.Participants> participants = new JAXBElement<MsgPartiesType.Participants>(qname,
				MsgPartiesType.Participants.class, participant);
		participant.getParticipant().add(msgPart);
		parties.setParticipants(participants);

		req.setParty(parties);
		
		OrderRetrieveRQ.Query query = new OrderRetrieveRQ.Query();
		OrderRetrieveRQ.Query.Filters filter = new OrderRetrieveRQ.Query.Filters();
		OrderIDType orderType = new OrderIDType();
		orderType.setOwner("BA");
		orderType.setValue(pnr);
		filter.setOrderID(orderType);
		query.setFilters(filter);
		
		req.setQuery(query);
		return req;
	}

	public DialogflowResponse convertToDFResponse(OrderViewRS orderViewRS) {
		DialogflowResponse res = new DialogflowResponse();
		List<FulfillmentMessages> fulfillmentMessagesList = new ArrayList<FulfillmentMessages>();
		FulfillmentMessages fulfillmentMessages = new FulfillmentMessages();
		List<String> ticket = new ArrayList<>();
		List<BigDecimal> amount = new ArrayList<>();
		String msg = new String();

		if(orderViewRS.getErrors() != null) {
		orderViewRS.getResponse().getTicketDocInfos().getTicketDocInfo().stream().forEach(ticketinfo -> {
			ticketinfo.getTicketDocument().forEach(ticketDoc -> {
				ticket.add(ticketDoc.getTicketDocNbr());
			});
		});

		orderViewRS.getResponse().getOrder().forEach(order -> {
			amount.add(order.getTotalOrderPrice().getSimpleCurrencyPrice().getValue());
		});

		if (ticket.size() > 1) {
			msg = ("There are multiple tickets for the provided PNR.You have submitted the refund request for tickets "
					+ ticket + " and the refund amount is :" + amount.get(0).longValue()
					+ "would you like to proceed with this?");
		} else {
			msg = ("You have submitted the refund request for ticket " + ticket.get(0) + " and the refund amount is :"
					+ amount.get(0).longValue() + "would you like to proceed with this?");
		}

		

		} else {
			msg = "Please check your PNR number and enter the correct series of six letters ";
		}
		
		List<String> msgList = new ArrayList<String>();
		Text text = new Text();
		text.setText(msgList);
		fulfillmentMessages.setText(text);
		fulfillmentMessagesList.add(fulfillmentMessages);
		msgList.add(msg);
		res.setFulfillmentMessages(fulfillmentMessagesList);
		res.setFulfillmentText(msg);
		return res;
	}

}
